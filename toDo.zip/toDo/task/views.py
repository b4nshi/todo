from django.http import HttpResponse
from django.shortcuts import redirect, render
from .models import Task


def home(request):
    if request.method == 'POST':
        input = request.POST['task']
        Task.objects.create(task=input)
        return redirect('home')
    obj = Task.objects.all()
    context = {'tasks': obj}
    return render(request, 'home.html', context)


