from django.http import HttpResponse
from django.shortcuts import render,redirect
from matplotlib.pyplot import title
from .models import Task

def home(request):
    if request.method == 'POST':
        title = request.POST['task'] 
        input = request.POST['description']
        Task.objects.create(task = title , description=input)
        return redirect('home')
    obj = Task.objects.all()
    context = {'tasks': obj}
    return render(request, 'home.html', context)


